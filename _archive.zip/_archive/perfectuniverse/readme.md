# Perfect universe

> TODO, not done yet

Idea is to create a set of tools to define your requirements in vlang and it will make it reality, little bit like Terraform

