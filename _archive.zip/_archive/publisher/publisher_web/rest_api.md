


- get on /blogs/$sitename/
  - returns json which shows which pages are block, with metadata like as used on our website https://www.threefold.io/blog
  - metata see data directory
- do same for the other types
  - https://github.com/threefoldfoundation/threefold_data/tree/development/content

- when we read the pages, we need to parse the frontend data, and remember it in a data structure per site, so when rest call comes we can give this data




