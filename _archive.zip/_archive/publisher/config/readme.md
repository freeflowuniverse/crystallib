# Config for publisher

is a set of json's which can be in a directory or more preferred use the actions feature for markdown docs.

see module "actionparser"

